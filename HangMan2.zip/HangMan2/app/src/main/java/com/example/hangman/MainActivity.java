package com.example.hangman;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.io.IOException;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    String[] words;
    String temp,x;
    StringBuilder temp2;
    int GuessNumber;
    TextView word,hint;
    EditText txt;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        x="";
        words = new String[]
        {"bound","play","negative","childrens","computerscience","school","freedom","donkey","spring","july","campfire","garage",
                "coach","celular","transfer","tedy","dustman",};
        word = (TextView)findViewById(R.id.theGuessWord);
        txt = (EditText)findViewById(R.id.ETxt);
        img = (ImageView)findViewById(R.id.Img);
        temp2 = new StringBuilder();
        hint = (TextView)findViewById(R.id.hint);
    }
    @Override
    protected void onStart() {
        super.onStart();
        Random r = new Random();
        int x = r.nextInt(words.length);
        temp = words[x];

        GuessNumber = 0;
        hint.setText("Guess the Word");
        for (int i=0; i<temp.length();i++){
            temp2.append("?");
        }
        word.setText(temp2);

    }
    public void Guess(View view) {
        try {


            if (txt.getText().toString().length() > 1) {
                hint.setText("Please enter one character");
            } else if (temp.contains(txt.getText().toString())) {
                char[] temp3 = temp.toCharArray();
                String x = txt.getText().toString();
                for (int i = 0; i < temp3.length; i++) {
                    if (x.charAt(0) == temp3[i]) {
                        temp2.replace(i, i + 1, x);
                    }
                }
                x = String.valueOf(temp2);
                if (!x.contains("?")) {
                    hint.setText("You Win :) \nClick on \"NEW\" to start again");
                }
                word.setText(temp2.toString());
            } else {
                x += txt.getText().toString().charAt(0);
                GuessNumber++;

                if (GuessNumber == 1) {
                    img.setImageResource(R.drawable.hangman5);
                    hint.setText("You have guessed: " + x + " (5 guesses left)");
                } else if (GuessNumber == 2) {
                    img.setImageResource(R.drawable.hangman4);
                    hint.setText("You have guessed: " + x + " (4 guesses left)");
                } else if (GuessNumber == 3) {
                    img.setImageResource(R.drawable.hangman3);
                    hint.setText("You have guessed: " + x + " (3 guesses left)");
                } else if (GuessNumber == 4) {
                    img.setImageResource(R.drawable.hangman2);
                    hint.setText("You have guessed: " + x + " (2 guesses left)");
                } else if (GuessNumber == 5) {
                    img.setImageResource(R.drawable.hangman1);
                    hint.setText("You have guessed: " + x + " (1 guess left)");
                } else {
                    img.setImageResource(R.drawable.hangman0);
                    hint.setText("Game Over :( The word is " + temp + " \nClick on \"NEW\" to start again");
                }
            }
        }catch (Exception e){
            hint.setText("Please enter your Guess");
        }
        txt.setText("");
    }public void New(View view) {
        temp2.delete(0,temp.length());
        x="";
        img.setImageResource(R.drawable.hangman6);
        GuessNumber=0;
        onStop();
        onStart();
    }


}
